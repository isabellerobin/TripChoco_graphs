import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.ArrayList;

public class MonCompo extends Component{ 
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Graphique graph;
	

		public void paint(Graphics arg0) { 
			Graphics2D g = (Graphics2D)arg0; 
			g.setColor(Color.blue);
			for (Point p : this.graph.getMesPoints()){
				g.fill3DRect((int)p.getX(),(int)p.getY(), 10, 10, true);
			}
			ArrayList<Point[]> edges = this.graph.getEdges();
			System.out.println("this.graph.getEdges().size() : "+this.graph.getEdges().size());
			System.out.println("this.graph.getDelaunayEdges().size() : "+this.graph.getDelaunayEdges().size());
			System.out.println("MonCompo : zonesRegroupement.size() : "+this.graph.getZonesRegroupement().size());
			for (Point[] arc : edges){
				Point p1 = arc[0];
				Point p2 = arc[1];
				g.drawLine((int)p1.getX(),(int) p1.getY(), (int)p2.getX(),(int) p2.getY());
			}
			for (int i=0;i<this.graph.getCentreZonesRegroupement().size();i++){
				int x=(int) this.graph.getCentreZonesRegroupement().get(i).getX();
				int y=(int) this.graph.getCentreZonesRegroupement().get(i).getY();
				g.drawOval(x-25,y-25,80,80);
			}
		}

	
			//g.drawLine(50,50,100,100);
			/*ArrayList<Point[]> edges = (ArrayList<Point[]>) delaunay.computeEdges();
			for (int i=0;i<nbPoints;i++){
				g.fill3DRect((int)mesPoints.get(i).getX(),(int)mesPoints.get(i).getY(), 10, 10, true);
			}
			for (int n=0;n<edges.size();n++){
				//System.out.println(n);
				g.drawLine((int)edges.get(n)[0].getX(), (int)edges.get(n)[0].getY(),(int)edges.get(n)[1].getX(),(int) edges.get(n)[1].getY());
			}

		}*/
		
		

		public MonCompo(Graphique graph) {
			super();
			this.graph = graph;
		}
	}