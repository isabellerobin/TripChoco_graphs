import java.awt.Point;
import java.util.ArrayList;


public class Graphique {
	ArrayList<Point> myPoints;
	ArrayList<Point[]> delaunayEdges;
	ArrayList<Point[]> edges;
	ArrayList<ArrayList<Point>> zonesRegroupement;
	Delaunay delaunay;
	ArrayList<Point> centresZonesRegroupement;

	public Graphique(int nbPoints, int nbPointsRegroupement) {
		super();
		this.delaunay = new Delaunay();
		this.myPoints = new ArrayList<Point>();
		this.zonesRegroupement= new ArrayList<ArrayList<Point>>();
		this.centresZonesRegroupement=new ArrayList<Point>();

		ArrayList<Point> zone1 = new ArrayList<Point>();
		ArrayList<Point> zone2 = new ArrayList<Point>();
		this.zonesRegroupement.add(zone1);
		this.zonesRegroupement.add(zone2);
		for (int j=0;j<nbPointsRegroupement;j++){
			int xPointRegroupement=0;
			int yPointRegroupement=0;
			zone1=new ArrayList<Point>();
			zone2=new ArrayList<Point>();
			for (int i=0;i<nbPoints/nbPointsRegroupement;i++){		
				int x=0;
				int y=0;
				if (i==0){
					xPointRegroupement=((int)(Display1.xWindow*Math.random()));
					yPointRegroupement=((int)(Display1.yWindow*Math.random()));
					x=xPointRegroupement;
					y=yPointRegroupement;
					//if (j==0){
						zone1.add(new Point(x,y));
						
					//}
					/*if (j==1){
						zone2.add(new Point(x,y));
					}*/
					centresZonesRegroupement.add(new Point(x,y));
				}
				else{
					if (i<9){
						if (Math.random()>0.5){
							x=xPointRegroupement+((int)(Display1.tailleZoneRegroupement*Math.random()));
						}
						else{
							x=xPointRegroupement-((int)(Display1.tailleZoneRegroupement*Math.random()));
						}
						if (Math.random()>0.5){
							y=yPointRegroupement+((int)(Display1.tailleZoneRegroupement*Math.random()));
						}
						else{
							y=yPointRegroupement-((int)(Display1.tailleZoneRegroupement*Math.random()));
						}
						//if (j==0){
							zone1.add(new Point(x,y));
						//}
						/*if (j==1){
							zone2.add(new Point(x,y));
						}*/					}
					else{
						if (i==9){
							if (Math.random()>0.5){
								x=xPointRegroupement+((int)(Display1.tailleZoneRegroupement*Math.random()));
							}
							else{
								x=xPointRegroupement-((int)(Display1.tailleZoneRegroupement*Math.random()));
							}
							if (Math.random()>0.5){
								y=yPointRegroupement+((int)(Display1.tailleZoneRegroupement*Math.random()));
							}
							else{
								y=yPointRegroupement-((int)(Display1.tailleZoneRegroupement*Math.random()));
							}
							//if (j==0){
								zone1.add(new Point(x,y));
							//}
							/*if (j==1){
								zone2.add(new Point(x,y));
							}	*/						
							//zonesRegroupement.add(zone1);
							System.out.println("Graphique : zonesRegroupement.size() : "+zonesRegroupement.size());
						}
						else{
							x=((int)(Display1.xWindow*Math.random()));
							y=((int)(Display1.yWindow*Math.random()));
						}
					}
				}
				myPoints.add(new Point(x,y));
				delaunay.insertPoint(new Point(x,y));
			}
		}


		ArrayList<Point[]> delaunayEdges = (ArrayList<Point[]>) delaunay.computeEdges();
		this.delaunayEdges = delaunayEdges;

		this.edges=new ArrayList<Point[]>();


		ArrayList<Point> alreadyLinked=new ArrayList<Point>();

		for (int i=0;i<delaunayEdges.size();i++){
			if (zone1.contains(delaunayEdges.get(i)[1])){
				if (!alreadyLinked.contains(delaunayEdges.get(i)[0])){
					edges.add(delaunayEdges.get(i));
					alreadyLinked.add(delaunayEdges.get(i)[0]);
				}
			}
			else{				
				if (zone1.contains(delaunayEdges.get(i)[0])){
					if (!alreadyLinked.contains(delaunayEdges.get(i)[1])){
						edges.add(delaunayEdges.get(i));
						alreadyLinked.add(delaunayEdges.get(i)[1]);
					}
				}
				else{
					edges.add(delaunayEdges.get(i));
				}

			}
		}
		


	}


	public ArrayList<Point> getMesPoints() {
		return myPoints;
	}

	public void setMesPoints(ArrayList<Point> mesPoints) {
		this.myPoints = mesPoints;
	}

	public ArrayList<Point[]> getEdges() {
		return edges;
	}

	public void setEdges(ArrayList<Point[]> edges) {
		this.edges = edges;
	}

	public ArrayList<Point[]> getDelaunayEdges() {
		return delaunayEdges;
	}

	public void setDelaunayEdges(ArrayList<Point[]> delaunayEdges) {
		this.delaunayEdges = delaunayEdges;
	}

	public ArrayList<ArrayList<Point>> getZonesRegroupement() {
		return zonesRegroupement;
	}

	public ArrayList<Point> getCentreZonesRegroupement() {
		return centresZonesRegroupement;
	}




}
