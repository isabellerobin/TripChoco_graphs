import java.awt.Point;


public class Place implements PlaceInterface {
	
	private Graph graph;
	
	private int id;
	
	private Point position;
	
	private int tav;
	
	private int sigma;
	
	private int tmin;
	
	private int tmax;
	
	private int basicscore;
	
	private int minscore;
	
	/*
	 * Si on utilise le regroupement :
	 * 
	 *  On garde les variables d'instances graph,id,position
	 * 
	 * Toutes les activit�s du lieu
	 * private ArrayList<Activity> allactivities;
	 * 
	 * L'activit� choisie
	 * private Activity electedActivity
	 * 
	 * Le score de l'activit� choisie
	 * private int score;
	 * 
	 * Le temps de l'activit� choisie
	 * private int time;
	 * 
	 * 
	 */
	
	
	public Place (Graph graph,int id, Point position, int tmoy, int ecarttype){
		this.graph = graph;
		this.id = id;
		this.position = position;
		this.tav = tmoy;
		this.sigma = ecarttype;
		this.tmin=this.minimumTime();
		this.tmax=this.maximumTime();
		this.basicscore = this.basicScore();
		this.minscore=this.minimumScore();
		
		this.graph.addPlace(this);
		
	}

	//Constructors for testing
	public Place (Graph graph, Point position, int time, int score){
		this.graph = graph;
		//Random id
		do {
			this.id = (int) (Graph.maxID*Math.random());
		}
		while (!this.getGraph().availableID(this.id));
		this.position = position;
		this.tav = time;
		this.basicscore = score;
		
		this.graph.addPlace(this);
		
	}
	
	public Place (Graph graph, Point position){
		this(graph,position,Integer.MAX_VALUE,Integer.MAX_VALUE);
	}
	
	public Graph getGraph() {
		return graph;
	}

	public void setGraph(Graph graph) {
		this.graph = graph;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Point getPosition() {
		return position;
	}

	public void setPosition(Point position) {
		this.position = position;
	}
	
	public int getTav() {
		return tav;
	}

	public void setTav(int tmoy) {
		this.tav = tmoy;
	}

	public int getSigma() {
		return sigma;
	}

	public void setSigma(int ecarttype) {
		this.sigma = ecarttype;
	}

	public int getTmin() {
		return tmin;
	}

	public void setTmin(int tmin) {
		this.tmin = tmin;
	}

	public int getTmax() {
		return tmax;
	}

	public void setTmax(int tmax) {
		this.tmax = tmax;
	}

	public int getBasicscore() {
		return basicscore;
	}

	public void setBasicscore(int basicscore) {
		this.basicscore = basicscore;
	}

	public int getMinscore() {
		return minscore;
	}

	public void setMinscore(int minscore) {
		this.minscore = minscore;
	}
	
	public int scoreMax(){
		int nbTag = this.getGraph().getAlltags().size();
		int nbPlaces = this.getGraph().getAllplaces().size();
		int nbPaths = this.getGraph().getAllpaths().size();
		int maxrank = nbPlaces + nbPaths;
		//The maximum score that a place can get is when it is top-ranked for every tag.
		//In any case, the user will have to rank every tag, so we can factorize
		//1 + 2 + 3 +... N = N(N-1)/2
		return (maxrank*(nbTag*(nbTag-1)/2));
	}
	
	public int basicScore(){
		int score = 0;
		for (Tag t : this.getGraph().getAlltags()){
			score += this.getGraph().getUser().getScore(t)*(t.getPlaceranking().size() - t.getPlaceranking().indexOf(this));
		}
		
		return score;
		
	}
	
	public int minimumTime(){
		return (2*(this.getTav() - this.getSigma())*(this.basicScore()/this.scoreMax()));
	
	}
	
	public int maximumTime() {
		return (2*this.getTav()*this.basicScore()/this.scoreMax());
	}
	
	public int minimumScore(){
		return this.scoreMax()*this.minimumTime()/this.maximumTime();
	}
	

	public String toString(){
		return id + " : " + "(" + this.getPosition().getX() + "," + this.getPosition().getY() + ") ; score : " + this.getBasicscore() + " ; time : " + this.getTav();
		
	}
	
}
